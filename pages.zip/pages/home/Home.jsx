import React from "react";
import onlinePdfConversion from "../../assets/body/Frame 116.svg";
import secondSectionImg from "../../assets/body/Frame 339.svg";
import tickIcon from "../../assets/body/Check Icon Tick.svg";
import popup from "../../assets/body/Frame 251.svg";
import thirdSectionImg from "../../assets/body/Frame 252.svg";
import one from "../../assets/body/Frame 237.svg";
import two from "../../assets/body/Frame 237 (1).svg";
import three from "../../assets/body/Frame 238.svg";
import four from "../../assets/body/Frame 240.svg";
import five from "../../assets/body/Frame 242.svg";
import fifthSectionImg from "../../assets/body/Frame 252 (1).svg";
import sixthSectionImg from "../../assets/body/Frame 252 (2).svg";
import eighthSectionImg from "../../assets/body/Frame 260.svg"

// import "../../App.css";
import "./home.css";
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import { Link, useNavigate } from "react-router-dom";


const Home = () => {


  const navigate = useNavigate()

  return (
    <div>
      <Header />
      <div className="uni-padding top-main">

        <div className="col-lg-12 mt-2 d-flex flex-wrap">
          <div className="col-lg-6 col-md-12 d-flex flex-column justify-content-around">
            <h1 className="heading-tools">Unlock your potential and secure admission into one of your top universities with support and guidance every step of the way.</h1>
            <span className="dummy-text">Get the clear strategy, guidance, and comprehensive resources you need to get more acceptances at top universities!</span>
            <div>
              <button className="book-btn">BOOK YOUR STRATEGY SESSION!</button>
            </div>
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12">
            <img src={onlinePdfConversion} className="img-fluid" alt="logo" />
          </div>
        </div>
        {/* /second section/ */}
        <div className="col-lg-12 d-flex align-items-center mt-5 flex-wrap" style={{ height: "100vh" }}>
          <div class="col-lg-5 col-md-12 col-sm-12">
            <img src={secondSectionImg} className="img-fluid" alt="logo" />
          </div>
          <div className="col-lg-7 col-md-12 d-flex flex-column justify-content-around">
            <h1 className="heading-tools">Parents of our extra support students are ready to do what it takes to solve these problems...</h1>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div>
            </div>
          </div>
        </div>

        <div className="col-lg-12 mt-2 d-flex align-items-center mt-5">
          <img src={popup} className="img-fluid mt-5 mb-5" alt="logo" />
        </div>

        <div className="col-lg-12 d-flex align-items-center justify-content-center flex-column mt-5 mb-5">
          <p className="dummy-text text-center w-50">You need a predictable college admissions approach to take away your uncertainty, guidance to get things done efficiently, and peace of mind so that you can finally stop chasing after answers and information and get your child an actionable plan that you trust.</p>
          <div>
            <button className="book-btn">BOOK YOUR STRATEGY SESSION!</button>
          </div>
        </div>
        {/* third section */}
        <div className="col-lg-12 mt-2 d-flex flex-wrap">
          <div className="col-lg-7 col-md-12 d-flex flex-column gap-4">
            <h1 className="heading-tools">No guarantees, but there are proactive steps you can take to significantly enhance your chances of success while decreasing the stress of the process.</h1>
            <span className="dummy-text">Admissions into your top choices has nothing to do with luck!</span>
            <div>
              <button className="book-btn" style={{ width: "35%" }}>LEARN MORE</button>
            </div>
          </div>
          <div class="col-lg-5 col-md-12 col-sm-12">
            <img src={thirdSectionImg} className="img-fluid" alt="logo" />
          </div>
        </div>
        {/* forth section */}
        <div className="col-lg-12 mt-5 p-4">
          <p className="third-heading">The College Mastermind Approach</p>
          <div className="d-flex gap-5 flex-wrap">
            <Link className="featuredBox p-4" to={"/"}>
              <img src={one} className="App-logo img-fluid" alt="logo" />
              <h1>Typical Applicant Pool</h1>
              <span className="description text-muted">Your typical applicant pool as a high achiever is 3.9+ unweighted GPA, 1500+ SAT and 34+ ACT</span>
              <div className="mt-3">
                <button className="book-btn" style={{ width: "100%" }}>LEARN MORE</button>
              </div>
            </Link>
            <Link className="featuredBox p-4" to={"/"}>
              <img src={two} className="App-logo img-fluid" alt="logo" />
              <h1>Typical Applicant Pool</h1>
              <span className="description text-muted">Your typical applicant pool as a high achiever is 3.9+ unweighted GPA, 1500+ SAT and 34+ ACT</span>
              <div className="mt-3">
                <button className="book-btn" style={{ width: "100%" }}>LEARN MORE</button>
              </div>
            </Link>
            <Link className="featuredBox p-4" to={"/"}>
              <img src={three} className="App-logo img-fluid" alt="logo" />
              <h1>Typical Applicant Pool</h1>
              <span className="description text-muted">Your typical applicant pool as a high achiever is 3.9+ unweighted GPA, 1500+ SAT and 34+ ACT</span>
              <div className="mt-3">
                <button className="book-btn" style={{ width: "100%" }}>LEARN MORE</button>
              </div>
            </Link>
            <Link className="featuredBox p-4" to={"/"}>
              <img src={four} className="App-logo img-fluid" alt="logo" />
              <h1>Typical Applicant Pool</h1>
              <span className="description text-muted">Your typical applicant pool as a high achiever is 3.9+ unweighted GPA, 1500+ SAT and 34+ ACT</span>
              <div className="mt-3">
                <button className="book-btn" style={{ width: "100%" }}>LEARN MORE</button>
              </div>
            </Link>
            <Link className="featuredBox p-4" to={"/"}>
              <img src={five} className="App-logo img-fluid" alt="logo" />
              <h1>Typical Applicant Pool</h1>
              <span className="description text-muted">Your typical applicant pool as a high achiever is 3.9+ unweighted GPA, 1500+ SAT and 34+ ACT</span>
              <div className="mt-3">
                <button className="book-btn" style={{ width: "100%" }}>LEARN MORE</button>
              </div>
            </Link>
          </div>
        </div>
        <div className="col-lg-12 d-flex align-items-center justify-content-center flex-column mt-5 mb-5">
          <p className="dummy-text text-center w-50">Following every step of our approach becomes even more important as the selectivity rate of your child's top 3 choices rises.</p>
          <div>
            <button className="book-btn">BOOK YOUR STRATEGY SESSION!</button>
          </div>
        </div>

        {/* fifth section */}
        <div className="col-lg-12 d-flex align-items-center mt-5 flex-wrap">
          <div class="col-lg-5 col-md-12 col-sm-12">
            <img src={fifthSectionImg} className="img-fluid" alt="logo" />
          </div>
          <div className="col-lg-7 col-md-12 d-flex flex-column justify-content-around">
            <h1 className="heading-tools">We want to connect with you if you are...</h1>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div className="d-flex gap-3">
              <img src={tickIcon} className="img-fluid" alt="logo" width={30} />
              <p className="dummy-text">Your child may have gaps in their profile, such as low social engagement, academic performance, anxiety, depression, or behaviors concerning to colleges.</p>
            </div>
            <div>
            </div>
          </div>
        </div>

        {/* sixth section */}
        <div className="col-lg-12 mt-2 d-flex gap-5 flex-wrap">
          <div className="col-lg-6 col-md-12 d-flex flex-column justify-content-center">
            <h1 className="heading-tools">More opportunities at top universities with more predictable results!</h1>
            <span className="dummy-text mt-3">We get results. We're not cheap, but the undeniable benefits of working with a support team during this process outweigh the costs for most families.
              <br /> <br />If you’re going to invest, get a results-driven approach that will give you confidence and reduce your stress.</span>
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12">
            <img src={sixthSectionImg} className="img-fluid" alt="logo" />
          </div>
        </div>

        {/* seventh section */}
        <div className="col-lg-12 mt-5 p-4">
          <div className="d-flex gap-5 flex-wrap justify-content-center">
            <Link className="featuredBox p-4 d-flex justify-content-center flex-column" to={"/"}>
              <span className="seventh-heading">Step 1</span>
              <h1>Book a 45-minute Strategy Session</h1>
              <span className="description text-muted">Gain clarity on your child’s current college admissions profile and learn what will be necessary for them to gain acceptance at the current universities on their list.</span>
            </Link>
            <Link className="featuredBox p-4 d-flex justify-content-center flex-column" to={"/"}>
            <span className="seventh-heading">Step 2</span>
              <h1>Join the College Mastermind Family</h1>
              <span className="description text-muted">Your typical applicant pool as a high achiever is 3.9+ unweighted GPA, 1500+ SAT and 34+ ACT</span>
            </Link>
          </div>
        </div>

        {/* eighth section */}
        <div className="col-lg-12 mt-2 d-flex mt-5 flex-wrap">
        <div class="col-lg-6 col-md-12 col-sm-12">
            <img src={eighthSectionImg} className="img-fluid" alt="logo" />
          </div>
          <div className="col-lg-6 col-md-12 d-flex flex-column justify-content-center">
            <h1 className="heading-tools">We don’t limit spaces due to volume</h1>
            <span className="dummy-text mt-3">We do not take on thousands of students per year, and we care about our reputation, so we need to make sure that you are going to trust us to know this process and know what works.</span>
            <div>
              <button className="book-btn mt-3">LEARN MORE</button>
            </div>
          </div>
        </div>
      </div>

      {<Footer />}
    </div>

  )
}

export default Home;