import React from "react";
import Logo from "../../assets/header/footer-logo.svg";
import facebook from "../../assets/footer/facebook.svg";
import twitter from "../../assets/footer/twitter.svg";
import linkedin from "../../assets/footer/linkedin.svg";
import "./footer.css"
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <div className="bg-clr uni-padding" >
      <div className="mb-5">
        <footer className="row col-lg-12 main-class mt-5">          
        <Link to="/">
              <img src={Logo} className="image-logo" alt="logo" />
        </Link>
        <div className="d-flex">
          <div className="col-md-6 col-sm-12 footer-heading">
              <div class="row mt-5">
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                  <h5 class="footer-heading">Quick Link</h5>

                  <ul class="list-unstyled d-flex flex-column gap-3 mb-0">
                    <li>
                      <a class="footer-text" href="#!">Home</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">About</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Services</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Partnership</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Packages</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Meet Our Team</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Contact US</a>
                    </li>
                  </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                  <h5 class="footer-heading">Services</h5>

                  <ul class="list-unstyled d-flex flex-column gap-3 mb-0">
                    <li>
                      <a class="footer-text" href="#!">5-Day Intensive</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Test Prep</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Admissions Service</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Scholarships</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">internship</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Events</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">FAQs</a>
                    </li>
                  </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                  <h5 class="footer-heading">Countries</h5>

                  <ul class="list-unstyled d-flex flex-column gap-3 mb-0">
                    <li>
                      <a class="footer-text" href="#!">Saudi Arabia</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">UAE</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Qatar</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Oman</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Kuwait</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">Bahrain</a>
                    </li>
                  </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                  <ul class="list-unstyled mb-0 gap-3 d-flex flex-column" style={{marginTop:'30px'}}>
                    <li>
                      <a class="footer-text" href="#!">China</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">India</a>
                    </li>
                    <li>
                      <a class="footer-text" href="#!">South Korea</a>
                    </li>
                  </ul>
                </div>
              </div>
          </div>

          <div className="col-md-6 col-sm-12">
            <section class="">
              <form action="" className="mt-5">
                <div class="row d-flex justify-content-center flex-column">
                  <div class="col-auto">
                    <p class="form-title">
                      Sign up for our newsletter
                    </p>
                  </div>

                  <div class="col-md-5 col-12">
                    <div data-mdb-input-init class="form-outline mb-4">
                      <input type="email" id="form5Example24" class="form-control" placeholder="Email" />
                    </div>
                  </div>

                  <div class="col-auto">
                  </div>
                </div>
              </form>
              <div className="gap-4 d-flex">
                <a href=""> <img src={facebook} alt="logo" width="10" /></a>
                <a href=""><img src={twitter} alt="logo" width="15" /></a>
                <a href=""><img src={facebook} alt="logo" width="10" /></a>
                <a href=""><img src={linkedin} alt="logo" width="15" /></a>
              </div>
            </section>
          </div>
          </div>
        </footer>
      </div>
      <hr />
      <div className="bottom-footer mt-5">
        <div>
        </div>
        <div className="footer-body gap-5">
          <a className="btn-footer">Privacy Policy</a>
          <a className="btn-footer">Legal Terms</a>
        </div>
      </div>
    </div>
  )
}

export default Footer;