import React from "react";
import "../header/header.css";
import "../../App.css";
import Logo from "../../assets/header/logo.svg";
import { Link } from 'react-router-dom';

function Header() {
    return (
        <div className="fixed-top top-nav">
            <header className="header navbar navbar-expand-lg mt-0">
                <Link to="/" className="navbar-brand">
                    <img src={Logo} className="image-logo" alt="logo" />
                </Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse justify-content-around" id="navbarNav">
                    <div className="d-flex align-items-center gap-5 navbar-nav">
                        <Link to="/" className="header-item nav-link">Home</Link>
                        <Link to="/" className="header-item nav-link">About</Link>
                        <Link to="/" className="header-item nav-link">Services</Link>
                        <Link to="/" className="header-item nav-link">Countries</Link>
                        <Link to="/" className="header-item nav-link">Partnership</Link>
                        <Link to="/" className="header-item nav-link">Events</Link>
                        <Link to="/" className="header-item nav-link">Contact Us</Link>
                    </div>
                    <div className="d-flex align-items-center gap-4">
                        <Link to="/" className="header-item"><button className="register-btn">
                            Register
                        </button>
                        </Link>
                        <Link to="/"><button className="login-btn">
                            Login
                        </button></Link>
                    </div>
                </div>
            </header>
        </div>

    )
}

export default Header;